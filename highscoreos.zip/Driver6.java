package Game2.Game;

import java.util.ArrayList;
import java.util.List;

public class Driver6 {

    public static void main(String[] args) {

        List<HighScore> scores = new ArrayList<HighScore>();

        // scores from file...
        scores = HighScore.readFromFile("HighScores3");

        for(HighScore hs : scores){
            System.out.println(hs);
        }
    }
}
