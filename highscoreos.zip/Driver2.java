package Game2.Game;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Driver2 {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        List<HighScore> scores = new ArrayList<HighScore>();

        // scores from file...
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("scores"));

        try {
            while(true){
                HighScore hs = (HighScore)ois.readObject();
                scores.add(hs);
            }
        }
        catch (EOFException e){
            // file empty!
        }

        ois.close();

        for(HighScore hs : scores){
            System.out.println(hs);
        }
    }
}
