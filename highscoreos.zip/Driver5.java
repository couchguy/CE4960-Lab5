package Game2.Game;

import java.io.IOException;
import java.util.ArrayList;

public class Driver5 {

    public static void main(String[] args) throws IOException {

        // Make some high scores
        ArrayList<HighScore> scores = new ArrayList<HighScore>();

        scores.add(new HighScore("Jim",50));
        scores.add(new HighScore("Ron",150));
        scores.add(new HighScore("Kim",250));
        scores.add(new HighScore("Sam",58));
        scores.add(new HighScore("Iam",450));
        scores.add(new HighScore("Mac",0));

        HighScore.writeToFile("HighScores3", scores);

        for(HighScore hs : scores){
            System.out.println(hs);
        }
    }
}
