package Game2.Game;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Driver {

    public static void main(String[] args) throws IOException {

        // Make some high scores
        ArrayList<HighScore> scores = new ArrayList<HighScore>();

        scores.add(new HighScore("Jim",50));
        scores.add(new HighScore("Ron",150));
        scores.add(new HighScore("Kim",250));
        scores.add(new HighScore("Sam",58));
        scores.add(new HighScore("Iam",450));
        scores.add(new HighScore("Mac",0));


        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("scores"));

        for(HighScore hs : scores){
            oos.writeObject(hs);
        }

        oos.close();


        for(HighScore hs : scores){
            System.out.println(hs);
        }

    }
}
