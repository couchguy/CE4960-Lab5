package Game2.Game;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// HighScore class
public class HighScore implements Serializable {

    public static final long serialVersionUID = 5L;

    private int score;
    private String name;

    public HighScore(){
        this.score = 0;
        this.name = "";
        return;
    }

    public HighScore(String name, int score){
        this.score = score;
        this.name = name;
        return;
    }

    public String toString(){
        if (score > 0)
            return name + " : " + score;
        else
            return name + " got pwned";
    }
















    // static methods
    // save scores to a file...
    public static int writeToFile(String filename,List<HighScore> scores){
        int count = 0;

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));

            oos.writeObject(scores);

            oos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return count;
    }

    public static List<HighScore> readFromFile(String filename){
        ArrayList<HighScore> scores = new ArrayList<HighScore>();

        try {
            // scores from file...
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename));

            scores = (ArrayList<HighScore>)ois.readObject();

            ois.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return scores;
    }


}
