package Game2.Game;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class Driver4 {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        List<HighScore> scores = new ArrayList<HighScore>();

        // scores from file...
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("scores2"));

        scores = (ArrayList<HighScore>)ois.readObject();

        ois.close();

        for(HighScore hs : scores){
            System.out.println(hs);
        }
    }
}
